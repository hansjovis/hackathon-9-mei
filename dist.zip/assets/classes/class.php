<?php

// This is just an example file.

class Plugin {
	const VERSION = "1.0.0";

	const LICENSE_KEY = "37e065f32df87f07d6179822645f483a1c4290c5ed0896552200cf91db9df49f";
}
