<?php

// This is just an example file.

class Plugin {
	const VERSION = "1.0.0";

	const LICENSE_KEY = "e3159530029c56a4b00bc1209b4696e5307655ed82cb773efaae8cd4a8666aff";
}
